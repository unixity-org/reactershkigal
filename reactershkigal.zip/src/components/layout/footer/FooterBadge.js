import BrandBadge from "@/components/shared/badges/BrandBadge";
const FooterBadge = () => {
  return <BrandBadge type="footer" />;
};

export default FooterBadge;
