import React from "react";

const ButtonPagination = ({}) => {
  return <div></div>;
};

export default ButtonPagination;
