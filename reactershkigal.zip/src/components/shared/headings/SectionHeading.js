const SectionHeading = ({ text }) => {
  return <h3 class="mb-0">{text}</h3>;
};

export default SectionHeading;
