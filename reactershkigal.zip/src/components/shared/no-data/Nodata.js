import React from "react";

const Nodata = ({ text }) => {
  return <p className="empty">{text}</p>;
};

export default Nodata;
