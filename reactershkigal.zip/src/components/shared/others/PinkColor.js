const PinkColor = () => {
  return <div className="pink__color"></div>;
};

export default PinkColor;
